
import React from "react";
import image from "../image.png";

const About = () => {
    return (
        <div>
            <img src={image} alt="Profile"/>
            <br />
            <h1>
                Hi! I'm Dhanush Kumar V, a B.Tech IT student at National Engineering College.Batch 2024 - 2027. I'm passionate about technology and eager to learn and grow in the field.
            </h1>
        </div>
    );
};

export default About;