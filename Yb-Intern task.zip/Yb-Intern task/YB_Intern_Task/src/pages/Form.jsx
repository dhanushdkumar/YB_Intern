
import React from 'react';

const Form = () => {
  return (
    <div>
      <table>
        <tr><td>Name</td><td>Dhanush Kumar V</td></tr>
        <tr><td>Degree</td><td>B.Tech IT</td></tr>
        <tr><td>College</td><td>National Engineering College</td></tr>
      </table>
    </div>
  );
};

export default Form;