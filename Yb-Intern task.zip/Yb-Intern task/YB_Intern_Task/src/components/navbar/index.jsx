
import React from "react";
import { NavLink } from "react-router-dom";

const Navbar = () => {
    return (
        <nav style={{ backgroundColor: '#333', padding: '10px' }}>
            <ul style={{ listStyleType: 'none', display: 'flex', margin: 0, padding: 0 }}>
                <li style={{ marginRight: '20px' }}>
                    <NavLink to="/" className={({ isActive }) => isActive ? "active" : ""} style={{ color: 'white', textDecoration: 'none' }}>
                        Home
                    </NavLink>
                </li>
                <li style={{ marginRight: '20px' }}>
                    <NavLink to="/about" className={({ isActive }) => isActive ? "active" : ""} style={{ color: 'white', textDecoration: 'none' }}>
                        About Me
                    </NavLink>
                </li>
                <li>
                    <NavLink to="/form" className={({ isActive }) => isActive ? "active" : ""} style={{ color: 'white', textDecoration: 'none' }}>
                        Form
                    </NavLink>
                </li>
            </ul>
        </nav>
    );
};

export default Navbar;